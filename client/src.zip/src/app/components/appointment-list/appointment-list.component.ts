import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MaterialModule } from '../../material/material.module';
import { AppointmentService } from '../../services/appointment.service';
import { DoctorService } from '../../services/doctor.service';
import { Appointment } from '../../models/appointment.model';
import { Doctor } from '../../models/doctor.model';

@Component({
  selector: 'app-appointment-list',
  standalone: true,
  imports: [CommonModule, RouterModule, MaterialModule],
  templateUrl: './appointment-list.component.html',
  styleUrls: ['./appointment-list.component.css']
})
export class AppointmentListComponent implements OnInit {
  appointments: Appointment[] = [];
  doctorsMap: { [key: number]: string } = {};
  loading = true;
  error = false;

  constructor(
    private appointmentService: AppointmentService,
    private doctorService: DoctorService
  ) {}

  ngOnInit(): void {
    this.loadDoctors();
    this.fetchAppointments();
  }

  loadDoctors() {
    this.doctorService.getDoctors().subscribe({
      next: (doctors: Doctor[]) => {
        doctors.forEach(doc => {
          this.doctorsMap[doc.id!] = doc.fullName;
        });
      },
      error: () => {
        this.error = true;
      }
    });
  }

  fetchAppointments() {
    this.appointmentService.getAppointments().subscribe({
      next: (data: Appointment[]) => {
        this.appointments = data;
        this.loading = false;
      },
      error: () => {
        this.error = true;
        this.loading = false;
      }
    });
  }

  cancelAppointment(id: number) {
    // Add logic here to cancel appointment (via service)
    console.log('Cancelling appointment:', id);
  }
}
